Place all files in /usr/bin.
